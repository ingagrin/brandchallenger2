/*
  # Create chat tables for conversation history

  1. New Tables
    - `chat_conversations`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to auth.users)
      - `title` (text)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    - `chat_messages`
      - `id` (uuid, primary key)
      - `conversation_id` (uuid, foreign key to chat_conversations)
      - `content` (text)
      - `sender` (text)
      - `timestamp` (timestamp)
      - `attachments` (jsonb, nullable)

  2. Security
    - Enable RLS on both tables
    - Add policies for users to access only their own conversations and messages
*/

-- Create chat_conversations table
CREATE TABLE IF NOT EXISTS public.chat_conversations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    title text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT chat_conversations_pkey PRIMARY KEY (id),
    CONSTRAINT chat_conversations_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE
);

-- Enable RLS on chat_conversations
ALTER TABLE public.chat_conversations ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for chat_conversations
CREATE POLICY "Enable read access for users based on user_id"
ON public.chat_conversations FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Enable insert for users based on user_id"
ON public.chat_conversations FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Enable update for users based on user_id"
ON public.chat_conversations FOR UPDATE
USING (auth.uid() = user_id);

CREATE POLICY "Enable delete for users based on user_id"
ON public.chat_conversations FOR DELETE
USING (auth.uid() = user_id);

-- Create chat_messages table
CREATE TABLE IF NOT EXISTS public.chat_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    conversation_id uuid NOT NULL,
    content text NOT NULL,
    sender text NOT NULL,
    timestamp timestamp with time zone DEFAULT now() NOT NULL,
    attachments jsonb,
    CONSTRAINT chat_messages_pkey PRIMARY KEY (id),
    CONSTRAINT chat_messages_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.chat_conversations(id) ON DELETE CASCADE
);

-- Enable RLS on chat_messages
ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for chat_messages
CREATE POLICY "Enable read access for messages in user's conversations"
ON public.chat_messages FOR SELECT
USING (
  EXISTS (
    SELECT 1
    FROM public.chat_conversations
    WHERE chat_conversations.id = chat_messages.conversation_id AND chat_conversations.user_id = auth.uid()
  )
);

CREATE POLICY "Enable insert for messages in user's conversations"
ON public.chat_messages FOR INSERT
WITH CHECK (
  EXISTS (
    SELECT 1
    FROM public.chat_conversations
    WHERE chat_conversations.id = chat_messages.conversation_id AND chat_conversations.user_id = auth.uid()
  )
);

CREATE POLICY "Enable update for messages in user's conversations"
ON public.chat_messages FOR UPDATE
USING (
  EXISTS (
    SELECT 1
    FROM public.chat_conversations
    WHERE chat_conversations.id = chat_messages.conversation_id AND chat_conversations.user_id = auth.uid()
  )
);

CREATE POLICY "Enable delete for messages in user's conversations"
ON public.chat_messages FOR DELETE
USING (
  EXISTS (
    SELECT 1
    FROM public.chat_conversations
    WHERE chat_conversations.id = chat_messages.conversation_id AND chat_conversations.user_id = auth.uid()
  )
);
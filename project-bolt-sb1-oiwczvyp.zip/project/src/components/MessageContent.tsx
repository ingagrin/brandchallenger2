import React from 'react';
import ReactMarkdown from 'react-markdown';

interface MessageContentProps {
  content: string;
  sender: 'user' | 'bot';
}

export default function MessageContent({ content, sender }: MessageContentProps) {
  if (sender === 'user') {
    return <span className="leading-relaxed">{content}</span>;
  }

  // Custom components for markdown rendering
  const components = {
    // Headings
    h1: ({ children }: any) => (
      <h1 className="text-xl font-bold text-gray-900 mb-3 mt-4 first:mt-0">{children}</h1>
    ),
    h2: ({ children }: any) => (
      <h2 className="text-lg font-bold text-gray-900 mb-2 mt-3 first:mt-0">{children}</h2>
    ),
    h3: ({ children }: any) => (
      <h3 className="text-base font-bold text-gray-900 mb-2 mt-3 first:mt-0">{children}</h3>
    ),
    
    // Paragraphs
    p: ({ children }: any) => (
      <p className="mb-3 leading-relaxed text-gray-800 last:mb-0">{children}</p>
    ),
    
    // Strong/Bold text
    strong: ({ children }: any) => (
      <strong className="font-bold text-gray-900">{children}</strong>
    ),
    
    // Emphasis/Italic text
    em: ({ children }: any) => (
      <em className="italic text-gray-700">{children}</em>
    ),
    
    // Code blocks
    code: ({ inline, children }: any) => {
      if (inline) {
        return (
          <code className="bg-gray-100 px-2 py-1 rounded text-sm font-mono text-gray-800">
            {children}
          </code>
        );
      }
      return (
        <pre className="bg-gray-100 p-3 rounded-lg overflow-x-auto mb-3">
          <code className="text-sm font-mono text-gray-800">{children}</code>
        </pre>
      );
    },
    
    // Lists
    ul: ({ children }: any) => (
      <ul className="mb-3 space-y-1">{children}</ul>
    ),
    ol: ({ children }: any) => (
      <ol className="mb-3 space-y-1 list-decimal list-inside">{children}</ol>
    ),
    li: ({ children }: any) => (
      <li className="flex items-start">
        <span className="text-gray-600 mr-2 mt-1 flex-shrink-0">•</span>
        <span className="flex-1 leading-relaxed text-gray-800">{children}</span>
      </li>
    ),
    
    // Blockquotes
    blockquote: ({ children }: any) => (
      <blockquote className="border-l-4 border-blue-200 pl-4 py-2 mb-3 bg-blue-50 italic text-gray-700">
        {children}
      </blockquote>
    ),
    
    // Links
    a: ({ href, children }: any) => (
      <a 
        href={href} 
        target="_blank" 
        rel="noopener noreferrer"
        className="text-blue-600 hover:text-blue-800 underline"
      >
        {children}
      </a>
    ),
    
    // Line breaks
    br: () => <br className="mb-2" />,
    
    // Horizontal rules
    hr: () => <hr className="border-gray-300 my-4" />,
  };

  return (
    <div className="space-y-1">
      <ReactMarkdown components={components}>
        {content}
      </ReactMarkdown>
    </div>
  );
}
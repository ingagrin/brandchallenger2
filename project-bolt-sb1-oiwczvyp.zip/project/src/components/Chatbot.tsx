import React, { useState, useRef, useEffect } from 'react';
import { Send, MessageCircle, User, Bot, Loader2, X, Sparkles } from 'lucide-react';
import MessageContent from './MessageContent';

interface Message {
  id: string;
  content: string;
  sender: 'user' | 'bot';
  timestamp: Date;
  isTyping?: boolean;
}

interface ChatbotProps {
  userId?: string;
}

export default function Chatbot({ userId = 'anonymous' }: ChatbotProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      content: 'Hello send me the doc',
      sender: 'bot',
      timestamp: new Date(),
    },
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [sessionId] = useState(() => {
    // Generate a random alphanumeric session ID
    return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
  });
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isOpen]);

  const formatBotResponse = (text: string): string => {
    // Clean up and format the response text with enhanced readability
    let formatted = text.trim();
    
    // Convert HTML to clean text with proper structure
    if (formatted.includes('<') && formatted.includes('>')) {
      formatted = formatted
        .replace(/<br\s*\/?>/gi, '\n')
        .replace(/<\/p>/gi, '\n\n\n')
        .replace(/<p[^>]*>/gi, '')
        .replace(/<\/div>/gi, '\n\n\n')
        .replace(/<div[^>]*>/gi, '')
        .replace(/<\/h[1-6]>/gi, '\n\n\n')
        .replace(/<h[1-6][^>]*>/gi, '\n\n🎯 **')
        .replace(/(<\/h[1-6]>)/gi, '**\n\n')
        .replace(/<\/?(strong|b)[^>]*>/gi, '**')
        .replace(/<\/?(em|i)[^>]*>/gi, '*')
        .replace(/<li[^>]*>/gi, '\n\n• ')
        .replace(/<\/li>/gi, '')
        .replace(/<\/?[uo]l[^>]*>/gi, '\n\n')
        .replace(/<[^>]*>/g, '')
        .replace(/&nbsp;/g, ' ')
        .replace(/&amp;/g, '&')
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .replace(/&quot;/g, '"')
        .replace(/&#39;/g, "'")
        .replace(/&apos;/g, "'");
    }
    
    // Extract content from JSON responses
    try {
      const parsed = JSON.parse(formatted);
      if (typeof parsed === 'string') {
        formatted = parsed;
      } else if (parsed.message) {
        formatted = parsed.message;
      } else if (parsed.response) {
        formatted = parsed.response;
      } else if (parsed.text) {
        formatted = parsed.text;
      }
    } catch {
      // Not JSON, continue with text processing
    }

    // Remove unwanted technical content and normalize whitespace
    formatted = formatted
      .replace(/^.*(?:chatInput|sessionId|userId|DOCTYPE|html|head|body|script|style).*$/gmi, '')
      .replace(/^\{.*\}$/gm, '')
      .replace(/\s+/g, ' ')  // Normalize spaces
      .replace(/\n\s*/g, '\n')  // Clean line breaks
      .replace(/\s*\n/g, '\n')
      
      // Format major section headers with enhanced styling
      .replace(/^(.{1,80}(?:brand analysis|analysis|assessment|evaluation|review):?.*)$/gmi, '\n\n📊 **$1**\n\n')
      .replace(/^(.{1,80}(?:challenge|problem|issue|concern|weakness):?.*)$/gmi, '\n\n⚠️ **$1**\n\n')
      .replace(/^(.{1,80}(?:recommendation|suggestion|advice|solution):?.*)$/gmi, '\n\n💡 **$1**\n\n')
      .replace(/^(.{1,80}(?:strategy|approach|plan|method|framework):?.*)$/gmi, '\n\n🎯 **$1**\n\n')
      .replace(/^(.{1,80}(?:summary|conclusion|takeaway|key points):?.*)$/gmi, '\n\n📋 **$1**\n\n')
      .replace(/^(.{1,80}(?:example|case study|illustration|sample):?.*)$/gmi, '\n\n📚 **$1**\n\n')
      .replace(/^(.{1,80}(?:insight|observation|finding|discovery):?.*)$/gmi, '\n\n🔍 **$1**\n\n')
      .replace(/^(.{1,80}(?:next steps|action items|to-do|implementation):?.*)$/gmi, '\n\n✅ **$1**\n\n')
      .replace(/^(.{1,80}(?:opportunity|potential|growth|advantage):?.*)$/gmi, '\n\n🚀 **$1**\n\n')
      .replace(/^(.{1,80}(?:competitive|competition|market|positioning):?.*)$/gmi, '\n\n⚔️ **$1**\n\n')
      
      // Format numbered lists with better spacing
      .replace(/^1\.\s*/gm, '\n🥇 **1.** ')
      .replace(/^2\.\s*/gm, '\n🥈 **2.** ')
      .replace(/^3\.\s*/gm, '\n🥉 **3.** ')
      .replace(/^([4-9])\.\s*/gm, '\n$1️⃣ **$1.** ')
      .replace(/^(10)\.\s*/gm, '\n🔟 **10.** ')
      .replace(/^(\d{2,})\.\s*/gm, '\n🔢 **$1.** ')
      
      // Format bullet points with enhanced spacing and context-aware emojis
      .replace(/^[-•*]\s*(?=.*(?:strength|advantage|benefit|positive|good|excellent|great|success))/gmi, '\n  ✅ ')
      .replace(/^[-•*]\s*(?=.*(?:weakness|disadvantage|problem|negative|bad|poor|lacking|issue))/gmi, '\n  ❌ ')
      .replace(/^[-•*]\s*(?=.*(?:opportunity|potential|growth|expand|scale|improve|enhance))/gmi, '\n  🚀 ')
      .replace(/^[-•*]\s*(?=.*(?:tip|advice|suggestion|recommend|consider|try|should))/gmi, '\n  💡 ')
      .replace(/^[-•*]\s*(?=.*(?:warning|caution|careful|avoid|don't|risk))/gmi, '\n  ⚠️ ')
      .replace(/^[-•*]\s*(?=.*(?:question|ask|wonder|curious|how|what|why))/gmi, '\n  ❓ ')
      .replace(/^[-•*]\s*(?=.*(?:example|instance|case|sample|illustration))/gmi, '\n  📝 ')
      .replace(/^[-•*]\s*(?=.*(?:result|outcome|impact|effect|consequence))/gmi, '\n  📈 ')
      .replace(/^[-•*]\s*/gm, '\n  🔸 ')
      
      // Highlight key business terms with enhanced formatting
      .replace(/\b(UVP|unique value proposition)\b/gi, '🎯 **$1**')
      .replace(/\b(brand positioning|positioning)\b/gi, '📍 **$1**')
      .replace(/\b(target audience|customer segment|ideal customer)\b/gi, '👥 **$1**')
      .replace(/\b(competitive advantage|differentiation)\b/gi, '⚡ **$1**')
      .replace(/\b(market research|market analysis)\b/gi, '📊 **$1**')
      .replace(/\b(brand identity|brand image)\b/gi, '🎨 **$1**')
      .replace(/\b(value proposition|core value)\b/gi, '💎 **$1**')
      .replace(/\b(customer journey|user experience)\b/gi, '🛤️ **$1**')
      
      // Add emotional context and emphasis with better formatting
      .replace(/\b(excellent|outstanding|amazing|fantastic|exceptional)\b/gi, '🌟 **$1**')
      .replace(/\b(important|crucial|critical|essential|vital)\b/gi, '🔥 **$1**')
      .replace(/\b(innovative|creative|unique|original)\b/gi, '💡 **$1**')
      .replace(/\b(successful|effective|powerful|strong)\b/gi, '💪 **$1**')
      .replace(/\b(growth|increase|improve|enhance|boost)\b/gi, '📈 **$1**')
      .replace(/\b(trust|reliable|authentic|credible)\b/gi, '🤝 **$1**')
      
      // Format quotes and questions with better spacing
      .replace(/"([^"]+)"/g, '\n\n💬 "*$1*"\n\n')
      .replace(/^(.+\?)$/gm, '\n❓ **$1**\n')
      
      // Format action words with emphasis
      .replace(/\b(consider|try|implement|focus|work on|start)\b/gi, '🎯 **$1**')
      .replace(/\b(avoid|don't|stop|eliminate|prevent)\b/gi, '⚠️ **$1**')
      .replace(/\b(remember|note|important|key point)\b/gi, '📌 **$1**')
      
      // Create proper paragraph spacing and structure
      .replace(/\n{4,}/g, '\n\n\n')  // Limit excessive line breaks
      .replace(/\n([🎯📊⚠️💡📋📚🔍✅🚀⚔️])/g, '\n\n$1')  // Space before section headers
      .replace(/(\*\*[^*]+\*\*)\n([^🎯📊⚠️💡📋📚🔍✅🚀⚔️\n])/g, '$1\n\n$2')  // Space after titles
      .replace(/([.!?])\s*\n([A-Z])/g, '$1\n\n$2')  // Paragraph breaks after sentences
      .replace(/(\n  [🔸✅❌🚀💡⚠️❓📝📈][^\n]+)\n([A-Z])/g, '$1\n\n$2')  // Space after bullet points
      
      // Final cleanup and normalization
      .replace(/\*\*\s*\*\*/g, '')
      .replace(/\*\s*\*/g, '')
      .replace(/^\s+/gm, '')
      .replace(/\s+$/gm, '')
      .replace(/\n{5,}/g, '\n\n\n')  // Final line break normalization
      .trim();
    
    // Enhanced fallback for problematic responses
    if (formatted.length < 10 || formatted.includes('<!') || formatted.match(/<[^>]+>/g)?.length > 2) {
      return '🤖 **Hello there!**\n\nI received your message, but I\'m having trouble processing the response format. Let me help you in a clearer way!\n\n\n💡 **I can assist you with:**\n\n  🔸 **Brand Analysis** - Understanding your current position\n\n  🔸 **UVP Development** - Creating compelling value propositions\n\n  🔸 **Competitive Strategy** - Standing out from competitors\n\n  🔸 **Target Audience** - Identifying your ideal customers\n\n\n❓ **What specific aspect of your brand would you like to explore?**';
    }
    
    return formatted;
  };

  const simulateTyping = async (content: string, callback: (partial: string) => void) => {
    const words = content.split(' ');
    let currentText = '';
    
    for (let i = 0; i < words.length; i++) {
      currentText += (i > 0 ? ' ' : '') + words[i];
      callback(currentText);
      
      // Variable delay based on word length and punctuation
      const delay = words[i].includes('.') || words[i].includes('!') || words[i].includes('?') 
        ? 100 : Math.random() * 50 + 30;
      
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  };

  const sendMessage = async (content: string) => {
    if (!content.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      content: content.trim(),
      sender: 'user',
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);
    setIsTyping(true);

    try {
      const response = await fetch('https://iamfashion.app.n8n.cloud/webhook/chat-brandchallenger-agent', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          chatInput: content.trim(),
          sessionId: sessionId,
          userId: userId,
        }),
      });

      if (!response.ok) {
        throw new Error(`Chat request failed (${response.status}): ${response.statusText}`);
      }

      let responseData;
      const contentType = response.headers.get('content-type');
      
      if (contentType && contentType.includes('application/json')) {
        // If response is JSON, parse it
        const jsonData = await response.json();
        responseData = typeof jsonData === 'string' ? jsonData : JSON.stringify(jsonData);
      } else {
        // If response is plain text, use it directly
        responseData = await response.text();
      }
      
      // Clean up the response and ensure it's properly formatted
      const rawResponse = responseData?.trim() || '🤔 I received your message, but got an empty response. Please try again.';
      const rawResponse = responseData?.trim() || 'I received your message, but got an empty response. Please try again.';
      const formattedResponse = formatBotResponse(rawResponse);

      // Create a temporary message for typing effect
      const tempBotMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: '',
        sender: 'bot',
        timestamp: new Date(),
        isTyping: true,
      };

      setMessages(prev => [...prev, tempBotMessage]);
      setIsLoading(false);

      // Simulate typing effect
      await simulateTyping(formattedResponse, (partialContent) => {
        setMessages(prev => 
          prev.map(msg => 
            msg.id === tempBotMessage.id 
              ? { ...msg, content: partialContent }
              : msg
          )
        );
      });

      // Mark typing as complete
      setMessages(prev => 
        prev.map(msg => 
          msg.id === tempBotMessage.id 
            ? { ...msg, isTyping: false }
            : msg
        )
      );
    } catch (error) {
      console.error('Chat error:', error);
      
      let errorContent = '😔 **Something went wrong**\n\nI encountered an issue while processing your request.';
      let errorContent = 'Something went wrong. I encountered an issue while processing your request.';
      
      if (error instanceof Error) {
        if (error.message.includes('500')) {
          errorContent = 'Workflow Issue: There is an issue with the brand analysis workflow. The system administrator has been notified. What you can try: Wait a moment and try again, Check if your message is clear and complete, Contact support if the issue persists';
        } else if (error.message.includes('404')) {
          errorContent = 'Service Not Found: The brand analysis service is currently unavailable. This usually means: The workflow is not active, The endpoint configuration needs updating';
        } else if (error.message.includes('timeout') || error.message.includes('network')) {
          errorContent = 'Connection Issue: I am having trouble connecting right now. Please try again in a moment. Tip: Make sure your internet connection is stable.';
        }
      }
      
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: errorContent,
        sender: 'bot',
        timestamp: new Date(),
      };

      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
      setIsTyping(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    sendMessage(inputValue);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage(inputValue);
    }
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 bg-gradient-to-r from-blue-600 to-purple-600 text-white p-4 rounded-full shadow-lg hover:shadow-xl transition-all duration-200 hover:scale-105 z-50"
        aria-label="Open chat"
      >
        <MessageCircle className="w-6 h-6" />
      </button>
    );
  }

  return (
    <div className="fixed bottom-6 right-6 w-96 h-[500px] bg-white rounded-2xl shadow-2xl border border-gray-200 flex flex-col z-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-4 rounded-t-2xl flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-semibold">🎯 Brand Challenger Agent</h3>
            <h3 className="font-semibold">Brand Challenger Agent</h3>
            <p className="text-xs text-white/80">
              {isTyping ? 'Typing...' : 'Online'}
            </p>
          </div>
        </div>
        <button
          onClick={() => setIsOpen(false)}
          className="text-white/80 hover:text-white transition-colors"
          aria-label="Close chat"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[80%] rounded-2xl px-4 py-2 ${
                message.sender === 'user'
                  ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white'
                  : 'bg-gray-100 text-gray-800'
              }`}
            >
              <div className="flex items-start space-x-2">
                {message.sender === 'bot' && (
                  <Bot className="w-4 h-4 mt-1 text-gray-600 flex-shrink-0" />
                )}
                <div className="flex-1">
                  <div className={`text-sm whitespace-pre-wrap ${
                    message.sender === 'user' ? 'leading-relaxed' : 'leading-loose'
                  }`}>
                    <MessageContent content={message.content} sender={message.sender} />
                  </div>
                  <p
                    className={`text-xs mt-1 ${
                      message.sender === 'user' ? 'text-white/70' : 'text-gray-500'
                    }`}
                  >
                    {formatTime(message.timestamp)}
                  </p>
                </div>
              </div>
            </div>
          </div>
        ))}
        
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-gray-100 rounded-2xl px-4 py-2 max-w-[80%]">
              <div className="flex items-center space-x-2">
                <Bot className="w-4 h-4 text-gray-600" />
                <div className="flex items-center space-x-1">
                  <Loader2 className="w-4 h-4 animate-spin text-gray-600" />
                  <span className="text-sm text-gray-600">🤔 Analyzing your brand...</span>
                  <span className="text-sm text-gray-600">Analyzing your brand...</span>
                </div>
              </div>
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="p-4 border-t border-gray-200">
        <form onSubmit={handleSubmit} className="flex space-x-2">
          <input
            ref={inputRef}
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="💬 Ask me about your brand's UVP..."
            placeholder="Ask me about your brand UVP..."
            disabled={isLoading || isTyping}
            className="flex-1 border border-gray-300 rounded-xl px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:opacity-50 disabled:cursor-not-allowed"
          />
          <button
            type="submit"
            disabled={isLoading || isTyping || !inputValue.trim()}
            className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-2 rounded-xl hover:from-blue-700 hover:to-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
            aria-label="Send message"
          >
            <Send className="w-5 h-5" />
          </button>
        </form>
        <p className="text-xs text-gray-500 mt-2 text-center">
          Session: {sessionId.substring(0, 8)}...
        </p>
      </div>
    </div>
  );
}
import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, Loader2, Sparkles, Paperclip, FileText, X, Save, Clock, History } from 'lucide-react';
import MessageContent from './MessageContent';
import { useChatHistory } from '../hooks/useChatHistory';

interface Message {
  id: string;
  content: string;
  sender: 'user' | 'bot';
  timestamp: Date;
  isTyping?: boolean;
  attachments?: Array<{
    name: string;
    size: number;
    type: string;
    documentType?: string;
    description?: string;
  }>;
}

interface IntegratedChatProps {
  userId?: string;
  userName?: string;
  brandName?: string;
  onLoadHistory?: () => Promise<Message[]>;
  onLoadN8NHistory?: () => Promise<Message[]>;
}

export default function IntegratedChat({ userId = 'anonymous', userName, brandName, onLoadHistory, onLoadN8NHistory }: IntegratedChatProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      content:`# Welcome to Brand Challenger

You're about to follow a guided path to a sharp, structured brand strategy.  
We keep it fast, focused, and practical — step by step, the agent tells you exactly what to send and what you'll get back.

---

## How it works
- The journey runs in three clear phases.  
- Please upload the files using these exact names.

---

### Phase 1 — Foundations

- **Personality Interview & PAP**  

**What you'll receive:** Your Brand Analysis, Recommendations to improve your brand documents, Brand Summary. You can then work your **brand UVP.

---

### Phase 2 — Customer Insights

- **Customer Interview Transcript**  
- **Order History (optional)**  

**What you'll get:** A deeper, data-driven understanding of your ideal customers,Ideal Customer Map.

---

### Phase 3 — Market Positioning

- **3 Competitors**  

**Outcome:** Competitor Benchmark, Your Positioning,Brand Voice recommendations.
`

,
      sender: 'bot',
      timestamp: new Date(),
    },
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [attachedFiles, setAttachedFiles] = useState<File[]>([]);
  const [isLoadingHistory, setIsLoadingHistory] = useState(false);
  const [isLoadingN8NHistory, setIsLoadingN8NHistory] = useState(false);
  const [sessionId] = useState(() => {
    return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
  });
  const [fileDocumentTypes, setFileDocumentTypes] = useState<{[key: string]: string}>({});
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleLoadHistory = async () => {
    if (!onLoadHistory) return;
    
    setIsLoadingHistory(true);
    try {
      const historyMessages = await onLoadHistory();
      
      // Keep the welcome message and add history messages after it
      const welcomeMessage = messages[0]; // First message is always welcome
      const newMessages = [welcomeMessage, ...historyMessages];
      setMessages(newMessages);
    } catch (error) {
      console.error('Error loading chat history:', error);
    } finally {
      setIsLoadingHistory(false);
    }
  };

  const handleLoadN8NHistory = async () => {
    if (!onLoadN8NHistory) return;
    
    setIsLoadingN8NHistory(true);
    try {
      const n8nHistoryMessages = await onLoadN8NHistory();
      
      // Keep the welcome message and add N8N history messages after it
      const welcomeMessage = messages[0]; // First message is always welcome
      const newMessages = [welcomeMessage, ...n8nHistoryMessages];
      setMessages(newMessages);
    } catch (error) {
      console.error('Error loading N8N chat history:', error);
    } finally {
      setIsLoadingN8NHistory(false);
    }
  };

  // Listen for webhook history load events from the sidebar button
  useEffect(() => {
    const handleWebhookHistoryEvent = (event: any) => {
      console.log('Received webhook history event:', event.detail);
      const webhookData = event.detail;
      
      if (webhookData && Array.isArray(webhookData) && webhookData.length > 0) {
        console.log('Processing webhook messages:', webhookData);
        const welcomeMessage = messages[0];
        
        // Convert webhook messages to proper format
        const formattedMessages = webhookData.map((msg: any, index: number) => {
          // Handle different message formats
          let content = '';
          let sender = 'bot';
          
          if (typeof msg === 'string') {
            content = msg;
          } else if (msg && typeof msg === 'object') {
            content = msg.content || msg.message || msg.text || String(msg);
            sender = msg.sender || msg.role || msg.type || 'bot';
            
            // Normalize sender types
            if (sender === 'human' || sender === 'customer' || sender === 'user') {
              sender = 'user';
            } else {
              sender = 'bot';
            }
          }
          
          return {
          id: `webhook-${Date.now()}-${index}`,
          content: String(content || '').trim(),
          sender: sender as 'user' | 'bot',
          timestamp: msg.timestamp ? new Date(msg.timestamp) : new Date(),
          attachments: msg.attachments
          };
        }).filter(msg => msg.content && msg.content.length > 0);
        
        if (formattedMessages.length > 0) {
          const newMessages = [welcomeMessage, ...formattedMessages];
          console.log('Setting new messages:', newMessages);
          setMessages(newMessages);
        } else {
          // Show "No history found" message
          const noHistoryMessage = {
            id: `no-history-${Date.now()}`,
            content: 'No history found',
            sender: 'bot' as const,
            timestamp: new Date()
          };
          const newMessages = [welcomeMessage, noHistoryMessage];
          setMessages(newMessages);
        }
      } else {
        console.log('No valid webhook messages received, showing no history message');
        const welcomeMessage = messages[0];
        const noHistoryMessage = {
          id: `no-history-${Date.now()}`,
          content: 'No history found',
          sender: 'bot' as const,
          timestamp: new Date()
        };
        const newMessages = [welcomeMessage, noHistoryMessage];
        setMessages(newMessages);
      }
    };

    window.addEventListener('loadWebhookHistory', handleWebhookHistoryEvent);
    return () => {
      window.removeEventListener('loadWebhookHistory', handleWebhookHistoryEvent);
    };
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const formatBotResponse = (text: string): string => {
    let formatted = text.trim();
    
    console.log('Raw response received:', formatted, 'Type:', typeof formatted);
    
    // Handle different response formats from webhook
    try {
      const parsed = JSON.parse(formatted);
      console.log('Parsed JSON response:', parsed, 'Type:', typeof parsed);
      
      // Handle direct string responses (most common from webhook)
      if (typeof parsed === 'string') {
        formatted = parsed;
      } 
      // Handle object responses with various field names
      else if (parsed && typeof parsed === 'object') {
        // Try to extract the actual response content in priority order
        formatted = parsed.output || parsed.message || parsed.content || parsed.data || 
                    parsed.response || parsed.text || parsed.result || parsed.answer ||
                    parsed.reply || parsed.body || parsed.value;
        
        // If none of the expected fields exist, try to find any string value
        if (!formatted) {
          const stringValues = Object.values(parsed).filter(v => typeof v === 'string' && v.trim().length > 0);
          if (stringValues.length > 0) {
            formatted = stringValues[0];
          }
        }
        
        // Last resort: stringify the object if it's not too large
        if (!formatted && JSON.stringify(parsed).length < 1000) {
          formatted = JSON.stringify(parsed, null, 2);
        }
      }
      // Handle array responses
      else if (Array.isArray(parsed) && parsed.length > 0) {
        const firstItem = parsed[0];
        formatted = typeof firstItem === 'string' ? firstItem : JSON.stringify(firstItem);
      }
    } catch (parseError) {
      console.log('Not JSON, processing as text. Parse error:', parseError);
      // If it's not JSON, continue with the original text
    }

    // If we still don't have valid content, check if it's an error response
    if (!formatted || formatted.length < 3) {
      console.log('Empty or invalid response, using fallback');
      return '🤖 **I received your message**\n\nI\'m processing your request, but the response seems to be empty. Could you please try rephrasing your question or check if there are any issues with the connection?';
    }

    // Convert to string if it's not already
    if (typeof formatted !== 'string') {
      formatted = String(formatted);
    }

    // Enhanced cleanup while preserving markdown structure
    formatted = formatted
      // Handle escaped characters from JSON
      .replace(/\\n/g, '\n')
      .replace(/\\r/g, '\r')
      .replace(/\\t/g, '\t')
      .replace(/\\"/g, '"')
      .replace(/\\'/g, "'")
      .replace(/\\\\/g, '\\')
      
      // Handle HTML entities
      .replace(/&quot;/g, '"')
      .replace(/&apos;/g, "'")
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&amp;/g, '&')
      .replace(/&nbsp;/g, ' ')
      .replace(/&#39;/g, "'")
      .replace(/&#34;/g, '"')
      
      // Remove technical/debug content
      .replace(/^.*(?:chatInput|sessionId|userId|DOCTYPE|html|head|body|script|style|output|webhook|error|debug).*$/gmi, '')
      .replace(/^\{.*\}$/gm, '')
      .replace(/^.*(?:endpoint|api|log|json|response|status|code).*$/gmi, '')
      
      // Clean up formatting
      .replace(/^["']|["']$/g, '')
      .replace(/^\{"output":\s*"|"\}$/g, '')
      .replace(/^output:\s*/gmi, '')
      
      // Normalize whitespace
      .replace(/[ \t]+/g, ' ')
      .replace(/\n[ \t]+/g, '\n')
      .replace(/[ \t]+\n/g, '\n')
      .replace(/\n{3,}/g, '\n\n')
      
      .trim();

    console.log('Final formatted response:', formatted);
    
    // Final validation
    if (!formatted || formatted.length < 5) {
      console.log('Response too short or empty after processing');
      return '🤖 **Thank you for your message!**\n\nI\'m having trouble generating a proper response right now. This could be due to:\n\n• The webhook is processing your request\n• There might be a temporary connection issue\n• The response format needs adjustment\n\nPlease try asking your question again, or let me know if you continue to see this message.';
    }
    
    return formatted;
  };

  const simulateTyping = async (content: string, callback: (partial: string) => void) => {
    // More natural typing simulation with word chunks
    const sentences = content.split(/([.!?]\s+)/);
    let currentText = '';
    
    for (let i = 0; i < sentences.length; i++) {
      const chunk = sentences[i];
      currentText += chunk;
      callback(currentText);
      
      // Variable delay for more natural feel
      let delay = 50;
      if (chunk.includes('.') || chunk.includes('!') || chunk.includes('?')) {
        delay = 300; // Longer pause after sentences
      } else if (chunk.includes(',')) {
        delay = 150; // Medium pause after commas
      } else if (chunk.includes('\n')) {
        delay = 200; // Pause for line breaks
      } else {
        delay = Math.random() * 80 + 40; // Random typing speed
      }
      
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  };

  const sendMessage = async (content: string) => {
    if (!content.trim() && attachedFiles.length === 0) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      content: content.trim() || (attachedFiles.length > 0 ? `📎 Attached ${attachedFiles.length} file${attachedFiles.length > 1 ? 's' : ''}` : ''),
      sender: 'user',
      timestamp: new Date(),
      attachments: attachedFiles.length > 0 ? attachedFiles.map(file => ({
        name: file.name,
        size: file.size,
        type: file.type,
      })) : undefined,
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setAttachedFiles([]);
    setFileDocumentTypes({});
    setIsLoading(true);
    setIsTyping(true);

    try {
      console.log('Sending chat request to:', 'https://iamfashion.app.n8n.cloud/webhook/dccf8360-e9ae-44df-8a2d-6cf329c76ec6');
      
      let response;
      
      if (attachedFiles.length > 0) {
        // Send as FormData when there are file attachments
        const formData = new FormData();
        const fileNames = attachedFiles.map(f => f.name).join(', ');
        formData.append('chatInput', content.trim() || `I have attached ${attachedFiles.length} document${attachedFiles.length > 1 ? 's' : ''}: ${fileNames}`);
        formData.append('sessionId', sessionId);
        formData.append('userId', userId);
        if (userName) formData.append('userName', userName);
        if (brandName) formData.append('brandName', brandName);
        
        // Append all files with proper handling for CSV
        attachedFiles.forEach((file, index) => {
          formData.append(`attachment_${index}`, file);
          formData.append(`attachment_${index}_name`, file.name);
          formData.append(`attachment_${index}_type`, file.type);
        });
        formData.append('attachmentCount', attachedFiles.length.toString());
        
        // For CSV files, also read and send the content as text for immediate processing
        const csvFiles = attachedFiles.filter(file => 
          file.type === 'text/csv' || 
          file.type === 'application/csv' || 
          file.name.toLowerCase().endsWith('.csv')
        );
        
        if (csvFiles.length > 0) {
          try {
            const csvContents = await Promise.all(
              csvFiles.map(async (file, index) => {
                const text = await file.text();
                return {
                  filename: file.name,
                  content: text,
                  index: attachedFiles.indexOf(file)
                };
              })
            );
            
            formData.append('csvData', JSON.stringify(csvContents));
            console.log('CSV content extracted and sent:', csvContents.map(c => ({ filename: c.filename, lines: c.content.split('\n').length })));
          } catch (error) {
            console.error('Error reading CSV files:', error);
          }
        }
        
        console.log('Sending with file attachment:', {
          chatInput: content.trim() || `I have attached ${attachedFiles.length} document${attachedFiles.length > 1 ? 's' : ''}: ${fileNames}`,
          sessionId: sessionId,
          userId: userId,
          fileCount: attachedFiles.length,
          fileNames: fileNames,
        });
        
        response = await fetch('https://iamfashion.app.n8n.cloud/webhook/dccf8360-e9ae-44df-8a2d-6cf329c76ec6', {
          method: 'POST',
          body: formData,
        });
      } else {
        // Send as JSON when there's no file
        console.log('Request payload:', {
          chatInput: content.trim(),
          sessionId: sessionId,
          userId: userId,
          userName: userName,
          brandName: brandName,
        });
        
        response = await fetch('https://iamfashion.app.n8n.cloud/webhook/dccf8360-e9ae-44df-8a2d-6cf329c76ec6', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            chatInput: content.trim(),
            sessionId: sessionId,
            userId: userId,
            userName: userName,
            brandName: brandName,
          }),
        });
      }

      console.log('Response status:', response.status);
      console.log('Response headers:', Object.fromEntries(response.headers.entries()));
      
      if (!response.ok) {
        let errorText;
        try {
          errorText = await response.text();
          console.error('Response error:', errorText);
        } catch (e) {
          console.error('Could not read error response:', e);
          errorText = 'Unknown error';
        }
        throw new Error(`Chat request failed (${response.status}): ${response.statusText}${errorText ? ' - ' + errorText : ''}`);
      }

      let responseData;
      const contentType = response.headers.get('content-type');
      console.log('Content type:', contentType);
      
      try {
        // Always read response as text first to avoid 'body stream already read' error
        const responseText = await response.text();
        console.log('Raw response text:', responseText);
        
        // Try to parse as JSON if it looks like JSON
        if (responseText.trim().startsWith('{') || responseText.trim().startsWith('[')) {
          try {
            responseData = JSON.parse(responseText);
            console.log('Parsed JSON response:', responseData);
          } catch (jsonError) {
            console.log('JSON parse failed, using as text:', jsonError);
            responseData = responseText;
          }
        } else {
          responseData = responseText;
          console.log('Using as text response:', responseData);
        }
      } catch (readError) {
        console.error('Error reading response:', readError);
        responseData = 'Error reading response';
      }
      
      // Handle the response data
      let rawResponse;
      if (typeof responseData === 'string') {
        rawResponse = responseData.trim();
      } else if (responseData && typeof responseData === 'object') {
        // Convert object to string for processing
        rawResponse = JSON.stringify(responseData);
      } else {
        rawResponse = String(responseData || '').trim();
      }
      
      if (!rawResponse) {
        rawResponse = 'I received your message, but got an empty response. Please try again.';
      }
      
      console.log('Raw response before formatting:', rawResponse);
      const formattedResponse = formatBotResponse(rawResponse);
      console.log('Formatted response ready for display:', formattedResponse);

      const tempBotMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: '',
        sender: 'bot',
        timestamp: new Date(),
        isTyping: true,
      };

      setMessages(prev => [...prev, tempBotMessage]);
      setIsLoading(false);

      await simulateTyping(formattedResponse, (partialContent) => {
        setMessages(prev => 
          prev.map(msg => 
            msg.id === tempBotMessage.id 
              ? { ...msg, content: partialContent }
              : msg
          )
        );
      });

      setMessages(prev => 
        prev.map(msg => 
          msg.id === tempBotMessage.id 
            ? { ...msg, isTyping: false }
            : msg
        )
      );
    } catch (error) {
      console.error('Chat error:', error);
      
      let errorContent = '😔 **Something went wrong**\n\nI encountered an issue while processing your request.';
      
      if (error instanceof Error) {
        if (error.message.includes('500')) {
          errorContent = 'Workflow Issue: There is an issue with the brand analysis workflow. The system administrator has been notified. What you can try: Wait a moment and try again, Check if your message is clear and complete, Contact support if the issue persists';
        } else if (error.message.includes('404')) {
          errorContent = 'Service Not Found: The brand analysis service is currently unavailable. This usually means: The workflow is not active, The endpoint configuration needs updating';
        } else if (error.message.includes('timeout') || error.message.includes('network')) {
          errorContent = 'Connection Issue: I am having trouble connecting right now. Please try again in a moment. Tip: Make sure your internet connection is stable.';
        }
      }
      
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: errorContent,
        sender: 'bot',
        timestamp: new Date(),
      };

      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
      setIsTyping(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputValue.trim() || attachedFiles.length > 0) {
      sendMessage(inputValue);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (inputValue.trim() || attachedFiles.length > 0) {
        sendMessage(inputValue);
      }
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    // Check file types and sizes
    const allowedTypes = [
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'text/plain',
      'text/csv',
      'application/csv',
      'application/vnd.ms-excel', // For CSV files that might be detected as Excel
      'image/jpeg',
      'image/png',
      'image/gif',
      'image/webp'
    ];
    
    const validFiles: File[] = [];
    const errors: string[] = [];
    
    files.forEach(file => {
      // Special handling for CSV files that might have different MIME types
      const isCSV = file.name.toLowerCase().endsWith('.csv') || 
                   file.type === 'text/csv' || 
                   file.type === 'application/csv' ||
                   file.type === 'application/vnd.ms-excel';
      
      if (!allowedTypes.includes(file.type) && !isCSV) {
        errors.push(`${file.name}: Invalid file type. Please select PDF, Word, CSV, text, or image files.`);
      } else if (file.size > 10 * 1024 * 1024) {
        errors.push(`${file.name}: File size must be less than 10MB.`);
      } else {
        validFiles.push(file);
      }
    });
    
    if (errors.length > 0) {
      alert(errors.join('\n'));
    }
    
    if (validFiles.length > 0) {
      // Add files directly without document type selection
      setAttachedFiles(prev => [...prev, ...validFiles]);
    }
    
    // Reset file input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const removeAttachment = (index: number) => {
    setAttachedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="bg-white rounded-xl border border-gray-200 overflow-hidden h-full flex flex-col max-h-[calc(100vh-12rem)]" data-chat-component>
      {/* Load History Button */}
      <div className="p-4 bg-gray-50 border-b border-gray-200">
        <h2 className="text-lg font-semibold text-gray-800">Brand Challenger Chat</h2>
      </div>

      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto p-6 space-y-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'} mb-4`}
          >
            <div
              className={`max-w-[80%] rounded-2xl px-6 py-4 ${
                message.sender === 'user'
                  ? 'bg-blue-500 text-white'
                  : 'bg-white text-gray-800 border border-gray-200 shadow-sm'
              }`}
            >
              <div className="flex-1">
                <div className="text-sm leading-relaxed">
                  <MessageContent content={message.content} sender={message.sender} />
                </div>
                {message.attachments && message.attachments.length > 0 && (
                  <div className="mt-3 space-y-2">
                    {message.attachments.map((attachment, index) => (
                      <div key={index} className="p-3 bg-gray-100 rounded-lg border border-gray-200">
                        <div className="flex items-center space-x-2">
                          <FileText className="w-4 h-4 text-gray-600" />
                          <div className="flex-1 min-w-0">
                            <div className="text-sm font-medium text-gray-800 truncate">{attachment.name}</div>
                            <div className="text-xs text-gray-600">
                              {(attachment.size / 1024 / 1024).toFixed(2)} MB
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
                <p
                  className={`text-xs mt-2 ${
                    message.sender === 'user' ? 'text-blue-100' : 'text-gray-500'
                  }`}
                >
                  {formatTime(message.timestamp)}
                </p>
              </div>
            </div>
          </div>
        ))}
        
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-white border border-gray-200 rounded-2xl px-6 py-4 max-w-[80%] shadow-sm">
              <div className="flex items-center space-x-2">
                <div className="flex items-center space-x-2">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                    <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  </div>
                  <span className="text-sm text-gray-600">Thinking...</span>
                </div>
              </div>
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>

      {/* Chat Input */}
      <div className="p-6 bg-gray-50 border-t border-gray-200 flex-shrink-0">
        {/* File Attachment Preview */}
        {attachedFiles.length > 0 && (
          <div className="mb-3 space-y-2">
            <div className="text-sm font-medium text-gray-700 mb-2">
              Attached Files ({attachedFiles.length})
            </div>
            {attachedFiles.map((file, index) => (
              <div key={index} className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                      <FileText className="w-4 h-4 text-blue-600" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium text-blue-900 truncate">
                        {file.name}
                      </div>
                      <div className="text-xs text-blue-600">
                        {(file.size / 1024 / 1024).toFixed(2)} MB • {file.type}
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={() => removeAttachment(index)}
                    className="text-blue-400 hover:text-blue-600 transition-colors"
                    aria-label="Remove attachment"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
            <button
              onClick={() => setAttachedFiles([])}
              className="text-sm text-gray-500 hover:text-gray-700 transition-colors"
            >
              Clear all attachments
            </button>
          </div>
        )}
        
        <form onSubmit={handleSubmit} className="flex space-x-4">
          <input
            ref={fileInputRef}
            type="file"
            onChange={handleFileSelect}
            accept=".pdf,.doc,.docx,.csv,.txt,.jpg,.jpeg,.png,.gif,.webp,text/csv,application/csv"
            multiple
            className="hidden"
          />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="text-gray-500 hover:text-[#0EA5E9] p-2 hover:bg-gray-100 rounded-lg transition-colors relative"
            aria-label="Attach files"
          >
            <Paperclip className="w-5 h-5" />
            {attachedFiles.length > 0 && (
              <span className="absolute -top-1 -right-1 bg-[#0EA5E9] text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                {attachedFiles.length}
              </span>
            )}
          </button>
          <input
            ref={inputRef}
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder={attachedFiles.length > 0 ? "Add a message about your documents..." : "Type your message..."}
            disabled={isLoading || isTyping}
            className="flex-1 border border-gray-300 rounded-xl px-6 py-4 focus:outline-none focus:ring-2 focus:ring-[#0EA5E9] focus:border-transparent disabled:opacity-50 disabled:cursor-not-allowed bg-white text-lg"
          />
          <button
            type="submit"
            disabled={isLoading || isTyping || (!inputValue.trim() && attachedFiles.length === 0)}
            className="bg-[#0EA5E9] hover:bg-blue-600 text-white px-8 py-4 rounded-xl focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#0EA5E9] disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 flex items-center space-x-2"
            aria-label="Send message"
          >
            <Send className="w-4 h-4" />
            <span className="hidden sm:inline">Send</span>
          </button>
        </form>
        <div className="flex items-center justify-between mt-4">
          <p className="text-xs text-gray-500">
            Session: {sessionId.substring(0, 8)}...
          </p>
          <div className="flex items-center space-x-1 text-xs text-gray-500">
            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
            <span>{isTyping ? 'Typing...' : 'Online'}</span>
          </div>
        </div>
      </div>

    </div>
  );
}
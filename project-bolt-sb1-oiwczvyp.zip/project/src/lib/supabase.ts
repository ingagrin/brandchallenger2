import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY

// Check if Supabase is properly configured
if (!supabaseUrl || !supabaseAnonKey || 
    supabaseUrl.includes('your-project-ref') || 
    supabaseAnonKey.includes('your-anon-key') ||
    supabaseUrl === 'https://placeholder.supabase.co' ||
    supabaseAnonKey === 'placeholder-key') {
  throw new Error(`
    Supabase is not properly configured. Please:
    1. Create a .env file in your project root
    2. Add your Supabase credentials:
       VITE_SUPABASE_URL="your-supabase-project-url"
       VITE_SUPABASE_ANON_KEY="your-supabase-anon-key"
    3. Restart your development server
    
    Get your credentials from: https://supabase.com/dashboard/project/[your-project]/settings/api
  `)
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Define the type for attachments as it appears in the database
type ChatAttachmentDB = Array<{
  name: string;
  size: number;
  type: string;
}>;

export type Database = {
  public: {
    Tables: {
      users: {
        Row: {
          id: string
          email: string
          first_name: string
          last_name: string
          brand_name: string
          created_at: string
          last_login: string
        }
        Insert: {
          id?: string
          email: string
          first_name: string
          last_name: string
          brand_name: string
          created_at?: string
          last_login?: string
        }
        Update: {
          id?: string
          email?: string
          first_name?: string
          last_name?: string
          brand_name?: string
          created_at?: string
          last_login?: string
        }
      }
      user_accounts: {
        Row: {
          id: string
          user_id: string
          account_status: string
          registration_source: string
          registration_ip: string | null
          email_verified: boolean
          last_activity: string
          account_created_at: string
          account_updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          account_status?: string
          registration_source?: string
          registration_ip?: string | null
          email_verified?: boolean
          last_activity?: string
          account_created_at?: string
          account_updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          account_status?: string
          registration_source?: string
          registration_ip?: string | null
          email_verified?: boolean
          last_activity?: string
          account_created_at?: string
          account_updated_at?: string
        }
      }
      chat_conversations: {
        Row: {
          id: string
          user_id: string
          title: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          title: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          title?: string
          created_at?: string
          updated_at?: string
        }
      }
      chat_messages: {
        Row: {
          id: string
          conversation_id: string
          content: string
          sender: string
          timestamp: string
          attachments: ChatAttachmentDB | null
        }
        Insert: {
          id?: string
          conversation_id: string
          content: string
          sender: string
          timestamp?: string
          attachments?: ChatAttachmentDB | null
        }
        Update: {
          id?: string
          conversation_id?: string
          content?: string
          sender?: string
          timestamp?: string
          attachments?: ChatAttachmentDB | null
        }
      }
    }
  }
}
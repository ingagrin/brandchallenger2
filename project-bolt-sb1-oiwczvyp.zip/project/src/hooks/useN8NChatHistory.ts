import { useState } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from './useAuth';

export interface N8NChatMessage {
  id: string;
  content: string;
  sender: 'user' | 'bot';
  timestamp: Date;
  attachments?: Array<{
    name: string;
    size: number;
    type: string;
  }>;
}

export interface N8NChatHistory {
  sessionId: string;
  messages: N8NChatMessage[];
  createdAt: Date;
  updatedAt: Date;
}

export function useN8NChatHistory() {
  const { user, isAuthenticated } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const loadN8NChatHistory = async (): Promise<N8NChatMessage[]> => {
    if (!user || !isAuthenticated) {
      console.log('User not authenticated, cannot load N8N chat history');
      return [];
    }

    try {
      setIsLoading(true);
      setError(null);

      console.log('Loading N8N chat history for user:', user.id);

      // First, get all session_ids for the authenticated user
      const { data: userDetails, error: userDetailsError } = await supabase
        .from('users_details')
        .select('session_id')
        .eq('authentification_id', user.id);

      if (userDetailsError) {
        console.error('Error loading user details:', userDetailsError);
        throw new Error(`Failed to load user details: ${userDetailsError.message}`);
      }

      if (!userDetails || userDetails.length === 0) {
        console.log('No user details found for user:', user.id);
        return [];
      }

      const sessionIds = userDetails.map(detail => detail.session_id);
      console.log('Found session IDs:', sessionIds);

      // Then, get all chat histories for those session_ids
      const { data: chatHistories, error: chatHistoriesError } = await supabase
        .from('n8n_chat_histories')
        .select('*')
        .in('session_id', sessionIds)
        .order('created_at', { ascending: true });

      if (chatHistoriesError) {
        console.error('Error loading chat histories:', chatHistoriesError);
        throw new Error(`Failed to load chat histories: ${chatHistoriesError.message}`);
      }

      if (!chatHistories || chatHistories.length === 0) {
        console.log('No chat histories found for session IDs:', sessionIds);
        return [];
      }

      console.log('Loaded chat histories:', chatHistories.length);

      // Convert the chat histories to messages format
      const allMessages: N8NChatMessage[] = [];

      chatHistories.forEach((history, historyIndex) => {
        // Add session separator if there are multiple sessions
        if (historyIndex > 0) {
          allMessages.push({
            id: `separator-${history.session_id}`,
            content: `--- Session ${history.session_id.substring(0, 8)}... (${new Date(history.created_at).toLocaleDateString()}) ---`,
            sender: 'bot',
            timestamp: new Date(history.created_at),
          });
        }

        // Parse messages from JSONB
        let messages = [];
        try {
          messages = Array.isArray(history.messages) ? history.messages : [];
        } catch (parseError) {
          console.error('Error parsing messages for session:', history.session_id, parseError);
          messages = [];
        }

        // Convert messages to our format
        messages.forEach((msg: any, msgIndex: number) => {
          try {
            allMessages.push({
              id: `n8n-${history.session_id}-${msgIndex}`,
              content: msg.content || msg.message || msg.text || String(msg),
              sender: msg.sender === 'user' ? 'user' : 'bot',
              timestamp: msg.timestamp ? new Date(msg.timestamp) : new Date(history.created_at),
              attachments: msg.attachments || undefined
            });
          } catch (msgError) {
            console.error('Error processing message:', msg, msgError);
          }
        });
      });

      console.log('Processed messages:', allMessages.length);
      return allMessages;

    } catch (error) {
      console.error('Error loading N8N chat history:', error);
      const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
      setError(errorMessage);
      return [];
    } finally {
      setIsLoading(false);
    }
  };

  return {
    loadN8NChatHistory,
    isLoading,
    error
  };
}
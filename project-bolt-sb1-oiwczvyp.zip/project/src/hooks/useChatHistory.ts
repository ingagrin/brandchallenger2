import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from './useAuth';

export interface ChatMessage {
  id: string;
  content: string;
  sender: 'user' | 'bot';
  timestamp: Date;
  attachments?: Array<{
    name: string;
    size: number;
    type: string;
  }>;
}

export interface ChatConversation {
  id: string;
  title: string;
  createdAt: Date;
  updatedAt: Date;
  messageCount: number;
}

export function useChatHistory() {
  const { user, isAuthenticated } = useAuth();
  const [conversations, setConversations] = useState<ChatConversation[]>([]);
  const [currentConversationId, setCurrentConversationId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Load conversations when user logs in
  useEffect(() => {
    if (isAuthenticated && user) {
      loadConversations();
    } else {
      setConversations([]);
      setCurrentConversationId(null);
    }
  }, [isAuthenticated, user]);

  const loadConversations = async () => {
    if (!user) return;

    try {
      setIsLoading(true);
      
      // Load conversations first
      const { data: conversationsData, error: conversationsError } = await supabase
        .from('chat_conversations')
        .select('id, title, created_at, updated_at')
        .eq('user_id', user.id)
        .order('updated_at', { ascending: false });

      if (conversationsError) {
        console.error('Error loading conversations:', conversationsError);
        // If tables don't exist, just return empty array instead of throwing
        if (conversationsError.code === '42P01') {
          console.log('Chat tables not yet created - this is normal for new installations');
          setConversations([]);
          return;
        }
        return;
      }

      // Load message counts separately
      const { data: messagesData, error: messagesError } = await supabase
        .from('chat_messages')
        .select('conversation_id')
        .in('conversation_id', (conversationsData || []).map(conv => conv.id));

      if (messagesError) {
        console.error('Error loading message counts:', messagesError);
        return;
      }

      // Calculate message counts for each conversation
      const messageCounts = (messagesData || []).reduce((acc, msg) => {
        acc[msg.conversation_id] = (acc[msg.conversation_id] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);

      const formattedConversations: ChatConversation[] = (conversationsData || []).map(conv => ({
        id: conv.id,
        title: conv.title,
        createdAt: new Date(conv.created_at),
        updatedAt: new Date(conv.updated_at),
        messageCount: messageCounts[conv.id] || 0
      }));

      setConversations(formattedConversations);
    } catch (error) {
      console.error('Error loading conversations:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const saveConversation = async (messages: ChatMessage[], title?: string) => {
    if (!user || !isAuthenticated || messages.length === 0) {
      console.log('Cannot save conversation: no user or no messages');
      return null;
    }

    try {
      setIsLoading(true);

      // Generate title from first user message or use provided title
      const conversationTitle = title || 
        messages.find(m => m.sender === 'user')?.content.substring(0, 50) + '...' || 
        'New Conversation';

      // Create conversation
      const { data: conversationData, error: conversationError } = await supabase
        .from('chat_conversations')
        .insert({
          user_id: user.id,
          title: conversationTitle
        })
        .select()
        .single();

      if (conversationError) {
        console.error('Error creating conversation:', conversationError);
        return null;
      }

      // Save messages
      const messagesToInsert = messages.map(message => ({
        conversation_id: conversationData.id,
        content: message.content,
        sender: message.sender,
        timestamp: message.timestamp.toISOString(),
        attachments: message.attachments ? JSON.stringify(message.attachments) : null
      }));

      const { error: messagesError } = await supabase
        .from('chat_messages')
        .insert(messagesToInsert);

      if (messagesError) {
        console.error('Error saving messages:', messagesError);
        // Clean up conversation if messages failed to save
        await supabase
          .from('chat_conversations')
          .delete()
          .eq('id', conversationData.id);
        return null;
      }

      // Reload conversations to update the list
      await loadConversations();
      
      return conversationData.id;
    } catch (error) {
      console.error('Error saving conversation:', error);
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  const loadConversationMessages = async (conversationId: string): Promise<ChatMessage[]> => {
    if (!user || !isAuthenticated) return [];

    try {
      const { data: messagesData, error } = await supabase
        .from('chat_messages')
        .select('*')
        .eq('conversation_id', conversationId)
        .order('timestamp', { ascending: true });

      if (error) {
        console.error('Error loading conversation messages:', error);
        return [];
      }

      return (messagesData || []).map(msg => ({
        id: msg.id,
        content: msg.content,
        sender: msg.sender as 'user' | 'bot',
        timestamp: new Date(msg.timestamp),
        attachments: msg.attachments ? JSON.parse(msg.attachments) : undefined
      }));
    } catch (error) {
      console.error('Error loading conversation messages:', error);
      return [];
    }
  };

  const deleteConversation = async (conversationId: string) => {
    if (!user || !isAuthenticated) return false;

    try {
      const { error } = await supabase
        .from('chat_conversations')
        .delete()
        .eq('id', conversationId)
        .eq('user_id', user.id);

      if (error) {
        console.error('Error deleting conversation:', error);
        return false;
      }

      // Reload conversations
      await loadConversations();
      
      // Clear current conversation if it was deleted
      if (currentConversationId === conversationId) {
        setCurrentConversationId(null);
      }

      return true;
    } catch (error) {
      console.error('Error deleting conversation:', error);
      return false;
    }
  };

  return {
    conversations,
    currentConversationId,
    setCurrentConversationId,
    isLoading,
    saveConversation,
    loadConversationMessages,
    deleteConversation,
    loadConversations
  };
}
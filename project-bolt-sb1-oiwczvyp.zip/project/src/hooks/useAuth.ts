import { useState, useEffect } from 'react';
import { User, AuthState, LoginCredentials } from '../types/auth';
import { supabase } from '../lib/supabase';

interface SimpleSignupData {
  email: string;
  password: string;
}

export function useAuth() {
  const [authState, setAuthState] = useState<AuthState>({
    user: null,
    isAuthenticated: false,
    isLoading: true,
  });

  // Load user from Supabase session on mount
  useEffect(() => {
    const loadUser = async () => {
      try {
        const { data: { session }, error } = await supabase.auth.getSession();
        
        if (error) {
          console.error('Error getting session:', error);
          setAuthState(prev => ({ ...prev, isLoading: false }));
          return;
        }

        if (session?.user) {
          const user: User = {
            id: session.user.id,
            email: session.user.email || '',
            firstName: session.user.user_metadata?.firstName || 'User',
            lastName: session.user.user_metadata?.lastName || '',
            brandName: session.user.user_metadata?.brandName || 'Brand',
            createdAt: new Date(session.user.created_at),
            lastLogin: new Date(),
          };

          setAuthState({
            user,
            isAuthenticated: true,
            isLoading: false,
          });
        } else {
          setAuthState(prev => ({ ...prev, isLoading: false }));
        }
      } catch (error) {
        console.error('Error loading user:', error);
        setAuthState(prev => ({ ...prev, isLoading: false }));
      }
    };

    loadUser();

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        if (event === 'SIGNED_IN' && session?.user) {
          const user: User = {
            id: session.user.id,
            email: session.user.email || '',
            firstName: session.user.user_metadata?.firstName || 'User',
            lastName: session.user.user_metadata?.lastName || '',
            brandName: session.user.user_metadata?.brandName || 'Brand',
            createdAt: new Date(session.user.created_at),
            lastLogin: new Date(),
          };

          setAuthState({
            user,
            isAuthenticated: true,
            isLoading: false,
          });
        } else if (event === 'SIGNED_OUT') {
          setAuthState({
            user: null,
            isAuthenticated: false,
            isLoading: false,
          });
        }
      }
    );

    return () => subscription.unsubscribe();
  }, []);

  const login = async (credentials: LoginCredentials): Promise<{ success: boolean; error?: string }> => {
    try {
      setAuthState(prev => ({ ...prev, isLoading: true }));

      const { data, error } = await supabase.auth.signInWithPassword({
        email: credentials.email,
        password: credentials.password,
      });

      if (error) {
        setAuthState(prev => ({ ...prev, isLoading: false }));
        return { success: false, error: error.message };
      }

      if (data.user) {
        // Call identify-user webhook
        try {
          const webhookUrl = 'https://iamfashion.app.n8n.cloud/webhook-test/identify-user';
          const payload = { user_email: data.user.email };
          console.log('Calling identify-user webhook (login):', webhookUrl, 'Payload:', payload);
          
          const response = await fetch(webhookUrl, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(payload),
          });
          
          if (response.ok) {
            const responseData = await response.json();
            console.log('Identify-user webhook response (login):', responseData);
          }
        } catch (error) {
          console.error('Failed to call identify-user webhook (login):', error);
        }

        return { success: true };
      }

      setAuthState(prev => ({ ...prev, isLoading: false }));
      return { success: false, error: 'Login failed' };
    } catch (error) {
      console.error('Login error:', error);
      setAuthState(prev => ({ ...prev, isLoading: false }));
      return { success: false, error: 'Login failed. Please try again.' };
    }
  };

  const signup = async (signupData: SimpleSignupData): Promise<{ success: boolean; error?: string }> => {
    try {
      // Check if Supabase is configured before attempting signup
      if (!import.meta.env.VITE_SUPABASE_URL || !import.meta.env.VITE_SUPABASE_ANON_KEY) {
        return { 
          success: false, 
          error: 'Supabase is not configured. Please set up your environment variables and restart the server.' 
        };
      }

      setAuthState(prev => ({ ...prev, isLoading: true }));

      const { data, error } = await supabase.auth.signUp({
        email: signupData.email,
        password: signupData.password,
        options: {
          data: {
            firstName: 'User',
            lastName: '',
            brandName: 'Brand',
          }
        }
      });

      if (error) {
        setAuthState(prev => ({ ...prev, isLoading: false }));
        return { success: false, error: error.message };
      }

      if (data.user) {
        // Call identify-user webhook
        try {
          const webhookUrl = 'https://iamfashion.app.n8n.cloud/webhook-test/identify-user';
          const payload = { user_email: data.user.email };
          console.log('Calling identify-user webhook (signup):', webhookUrl, 'Payload:', payload);
          
          const response = await fetch(webhookUrl, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(payload),
          });
          
          if (response.ok) {
            const responseData = await response.json();
            console.log('Identify-user webhook response (signup):', responseData);
          }
        } catch (error) {
          console.error('Failed to call identify-user webhook (signup):', error);
        }

        console.log('User signup completed with Supabase Auth:', data.user.email);
        return { success: true };
      }

      setAuthState(prev => ({ ...prev, isLoading: false }));
      return { success: false, error: 'Signup failed' };
    } catch (error) {
      console.error('Signup error:', error);
      setAuthState(prev => ({ ...prev, isLoading: false }));
      return { success: false, error: 'Signup failed. Please try again.' };
    }
  };

  const logout = async () => {
    try {
      await supabase.auth.signOut();
    } catch (error) {
      console.error('Logout error:', error);
    }
    // State will be updated by the auth state change listener
  };

  const updateUserSettings = async (settings: any): Promise<{ success: boolean; error?: string }> => {
    if (!authState.user) {
      return { success: false, error: 'User not authenticated.' };
    }

    try {
      setAuthState(prev => ({ ...prev, isLoading: true }));

      // Update user metadata in Supabase
      const { error } = await supabase.auth.updateUser({
        data: {
          firstName: settings.firstName,
          lastName: settings.lastName,
          brandName: settings.brandName,
        }
      });

      if (error) {
        setAuthState(prev => ({ ...prev, isLoading: false }));
        return { success: false, error: error.message };
      }

      // Update password if provided
      if (settings.newPassword) {
        const { error: passwordError } = await supabase.auth.updateUser({
          password: settings.newPassword
        });

        if (passwordError) {
          setAuthState(prev => ({ ...prev, isLoading: false }));
          return { success: false, error: passwordError.message };
        }
      }

      // Update local state
      const updatedUser: User = {
        ...authState.user,
        firstName: settings.firstName,
        lastName: settings.lastName,
        brandName: settings.brandName,
        email: settings.email,
      };

      setAuthState(prev => ({
        ...prev,
        user: updatedUser,
        isLoading: false,
      }));
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedUser));
      return { success: true };
    } catch (error) {
      setAuthState(prev => ({ ...prev, isLoading: false }));
      return { success: false, error: 'Failed to update settings. Please try again.' };
    }
  };

  return {
    ...authState,
    login,
    signup,
    logout,
    updateUserSettings,
  };
}